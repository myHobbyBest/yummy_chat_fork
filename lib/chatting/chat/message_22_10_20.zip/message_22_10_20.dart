

//import 'package:firebase_chat/chatting/chat/chat_bubble.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'chat_bubble.dart';
import 'get_userdata.dart';

import 'globals.dart' as globals;
import 'is_first_chat.dart';

               var _userName;
               var _url;
class Messages extends StatelessWidget  {
  // const Messages({Key? key}) : super(key: key);

  String url='';
  @override
  Widget build(BuildContext context) {
    final _user = FirebaseAuth.instance.currentUser;
    return StreamBuilder(
      stream: FirebaseFirestore.instance
          .collection('chat')
          .orderBy('time', descending: true)
          .snapshots(),
      builder: (context,
          AsyncSnapshot<QuerySnapshot<Map<String, dynamic>>> snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting ) {
          return Center(
            child: CircularProgressIndicator(),
          );
        }
        final chatDocs = snapshot.data!.docs;

        getData(0) ;
 
        if (globals.userData==null){
          // Future.delayed(Duration(milliseconds: 2000), () {
          //   // Do something
          // });
          return Center(
            child: CircularProgressIndicator(),
          );
        }else {
          return ListView.builder(
            reverse: true,
            itemCount: chatDocs.length,
            itemBuilder: (context, index) {
              isFirstChat();
              var  userId = chatDocs[index]['userID'].toString();
              var _userData=globals.userData[userId];
              if (   index!=0){
                globals.isSignUpUser=false;
              }
             if (   index==0 && (userId != _user!.uid && globals.isChatDoc ||
                                globals.isSignUpUser && userId == _user!.uid )
               ){//|| globals.isSignUpUser && globals.isFirstChat          

              //  print ( '## It is chatDocs[] ## ' );
              //  print( _userData);
               _userName = chatDocs[index]['userName'];
               _url  =     chatDocs[index]['userImage'];
               
               if(globals.isChatDoc){
                print ( '## It is isChatDoc ## ' );
              }   
               if(globals.isSignUpUser){
                print ( '## It is isSignUpUser ## ' );
              }  
              
             }else{            
        //       print( 'userName : ${_userData['userName']}');
        //       print( 'userName : ${_userData['userName']}');
               print ( '## It is Not chatDocs[] ## ' );   
              //  _userName =_userData['userName'];
              //  _url  = _userData['picked_image'];    


              //  if(globals.isChatDoc){
              //   print ( '## It is isChatDoc ## ' );
              // }   

              //  if(globals.isSignUpUser){
              //   print ( '## It is isSignUpUser ## ' );
              // }  
              //     
             }
               return ChatBubbles(
                  chatDocs[index]['text'],
                  userId == _user!.uid,
                  chatDocs[index]['userName'],
                  chatDocs[index]['userImage']
               );

            }, // itemBuilder:
          );
        }//else====================
      },
    );
  }
}
